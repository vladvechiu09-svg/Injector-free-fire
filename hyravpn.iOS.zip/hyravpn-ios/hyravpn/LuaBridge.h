#include <stddef.h>
int hyra_lua_run(const void *source, size_t length, char *output, size_t capacity);
