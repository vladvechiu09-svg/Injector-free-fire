#include "LuaBridge.h"
#include "lua.h"
#include "lauxlib.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct { size_t used; unsigned ticks; } Limits;
static void *limited_alloc(void *ud, void *ptr, size_t old, size_t n) {
    Limits *l = ud;
    if (!ptr) old = 0;
    if (!n) { free(ptr); l->used -= old; return NULL; }
    if (n > old && n-old > 8*1024*1024-l->used) return NULL;
    void *next = realloc(ptr,n);
    if (next) l->used = l->used-old+n;
    return next;
}
static void instruction_limit(lua_State *L, lua_Debug *ar) {
    (void)ar;
    Limits *l = *(Limits **)lua_getextraspace(L);
    if (++l->ticks >= 1000) luaL_error(L,"Limita de instructiuni a fost atinsa");
}
int hyra_lua_run(const void *source, size_t length, char *output, size_t capacity) {
    if (!output || !capacity) return 1;
    output[0] = '\0';
    if (!source || !length || length > 262144) { snprintf(output,capacity,"Script gol sau prea mare (max. 256 KB)"); return 1; }
    Limits limits = {0,0};
    lua_State *L=lua_newstate(limited_alloc,&limits);
    if (!L) { snprintf(output,capacity,"Nu s-a putut initializa Lua"); return 1; }
    *(Limits **)lua_getextraspace(L)=&limits;
    lua_sethook(L,instruction_limit,LUA_MASKCOUNT,1000);
    /* No standard libraries or host APIs are exposed to imported scripts. */
    int rc=luaL_loadbufferx(L,source,length,"local-script","t");
    if (rc==LUA_OK) rc=lua_pcall(L,0,1,0);
    if (rc!=LUA_OK) { const char *msg=lua_tostring(L,-1); snprintf(output,capacity,"%s",msg?msg:"Eroare Lua"); }
    else switch(lua_type(L,-1)) {
        case LUA_TNUMBER: snprintf(output,capacity,"%.15g",(double)lua_tonumber(L,-1)); break;
        case LUA_TSTRING: snprintf(output,capacity,"%s",lua_tostring(L,-1)); break;
        case LUA_TBOOLEAN: snprintf(output,capacity,"%s",lua_toboolean(L,-1)?"true":"false"); break;
        case LUA_TNIL: snprintf(output,capacity,"nil (fara rezultat)"); break;
        default: snprintf(output,capacity,"Rezultat: %s",lua_typename(L,lua_type(L,-1))); break;
    }
    lua_close(L);
    return rc;
}
