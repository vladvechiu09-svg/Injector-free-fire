import SwiftUI
import UniformTypeIdentifiers
import UIKit

@main
struct HyravpnApp: App {
    var body: some Scene { WindowGroup { ContentView().preferredColorScheme(.dark) } }
}

struct ConfigFile: Identifiable, Codable {
    var id = UUID()
    var name: String
    var data: Data
    var description: String
    var bundled = false
    var text: String { String(data: data, encoding: .utf8) ?? "Fișier binar: \(data.count) octeți" }
}

struct ContentView: View {
    @Environment(\.openURL) private var openURL
    @AppStorage("sensiGeneral") private var sensiGeneral = 100.0
    @AppStorage("sensiRedDot") private var sensiRedDot = 100.0
    @AppStorage("sensi2x") private var sensi2x = 100.0
    @AppStorage("sensi4x") private var sensi4x = 100.0
    @AppStorage("sensiSniper") private var sensiSniper = 100.0
    @AppStorage("sensiFreeLook") private var sensiFreeLook = 100.0
    @AppStorage("sensiMax") private var sensiMax = 200
    @AppStorage("aimPrecision") private var aimPrecision = "Implicită"
    @AppStorage("confirmedNames") private var confirmedNames = ""
    @State private var files: [ConfigFile] = []
    @State private var selected = Set<UUID>()
    @State private var importing = false
    @State private var runningLua = false
    @State private var luaOutput = ""
    @State private var preview: ConfigFile?
    @State private var status = "Fișiere locale • fără acces la datele jocului"
    private let violet = Color(red: 0.67, green: 0.35, blue: 0.98)
    private let panel = Color(red: 0.10, green: 0.065, blue: 0.15)
    private let gradient = LinearGradient(colors: [Color(red: 0.50, green: 0.12, blue: 0.83), Color(red: 0.85, green: 0.15, blue: 0.28), Color(red: 1, green: 0.65, blue: 0.13)], startPoint: .leading, endPoint: .trailing)
    private var storage: URL { FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("hyravpn-files.json") }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    HStack {
                        Image(systemName: "shield.lefthalf.filled").font(.system(size: 28)).foregroundStyle(violet)
                        Text("hyravpn").font(.system(size: 32, weight: .heavy, design: .rounded))
                        Spacer()
                        Text("AUXÍLIO • iOS").font(.caption.bold()).padding(8).background(panel, in: Capsule())
                    }
                    Capsule().fill(gradient).frame(height: 3)
                    VStack(spacing: 10) {
                        Image(systemName: "gamecontroller.fill").font(.system(size: 55)).foregroundStyle(gradient)
                        Text("FREE FIRE").font(.title2.bold()).tracking(3)
                        Text("AUXÍLIO DE MIRA").font(.subheadline.weight(.semibold)).tracking(2).foregroundStyle(violet)
                        Text("Configurări locale • lansator").font(.caption).foregroundStyle(.secondary)
                    }.frame(maxWidth: .infinity).padding(28).background(panel, in: RoundedRectangle(cornerRadius: 24)).overlay(RoundedRectangle(cornerRadius: 24).stroke(violet.opacity(0.3)))
                    action("Deschide Free Fire", "arrow.up.forward.app") {
                        guard let url = URL(string: "freefire://") else { return }
                        openURL(url) { accepted in if !accepted { status = "iOS nu a găsit o aplicație care acceptă freefire://." } }
                    }
                    HStack {
                        Text("Module locale").font(.title3.bold())
                        Spacer()
                        Button(selected.count == files.count && !files.isEmpty ? "Deselectează" : "Selectează tot") {
                            selected = selected.count == files.count ? [] : Set(files.map(\.id))
                        }.font(.caption.bold()).foregroundStyle(violet)
                    }
                    if files.isEmpty {
                        Text("Nu există fișiere importate. Poți importa configurații proprii pentru citire și arhivare.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                    ForEach(files) { file in
                        HStack(spacing: 12) {
                            Button { if selected.contains(file.id) { selected.remove(file.id) } else { selected.insert(file.id) } } label: {
                                Image(systemName: selected.contains(file.id) ? "checkmark.square.fill" : "square").font(.title2).foregroundStyle(violet)
                            }.buttonStyle(.plain).accessibilityLabel("Selectează \(file.name)")
                            Image(systemName: "doc.text").foregroundStyle(violet)
                            VStack(alignment: .leading, spacing: 5) {
                                Text(file.name).font(.subheadline.bold()).lineLimit(2)
                                Text(file.description).font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Button { preview = file } label: { Image(systemName: "chevron.right").padding(8).foregroundStyle(violet) }.buttonStyle(.plain).accessibilityLabel("Vezi codul \(file.name)")
                        }.padding(16).background(panel, in: RoundedRectangle(cornerRadius: 16))
                    }
                    Button { importing = true } label: {
                        Label("Importă fișiere", systemImage: "folder.badge.plus").font(.headline).frame(maxWidth: .infinity).padding(16).overlay(RoundedRectangle(cornerRadius: 16).stroke(violet.opacity(0.6)))
                    }.buttonStyle(.plain)
                    action("Confirmă selecția (\(selected.count))", "checkmark") {
                        let names = files.filter { selected.contains($0.id) }.map(\.name)
                        confirmedNames = names.joined(separator: "\n")
                        status = "\(names.count) fișiere selectate și salvate local."
                    }.disabled(selected.isEmpty).opacity(selected.isEmpty ? 0.5 : 1)
                    action(runningLua ? "Executare Lua…" : "Execută scripturile selectate", "play.fill") {
                        runLua()
                    }.disabled(runningLua || selected.isEmpty).opacity(runningLua || selected.isEmpty ? 0.5 : 1)
                    if !luaOutput.isEmpty {
                        Text(luaOutput).font(.system(.footnote, design: .monospaced)).textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: .leading).padding(14).background(panel, in: RoundedRectangle(cornerRadius: 12))
                    }
                    Text(status).font(.footnote).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading)
                    if !confirmedNames.isEmpty {
                        Text("Ultima selecție: " + confirmedNames.replacingOccurrences(of: "\n", with: ", ")).font(.caption).foregroundStyle(.secondary)
                    }
                    sensitivityPanel
                    VStack(alignment: .leading, spacing: 12) {
                        Label("Ghid oficial de țintire", systemImage: "info.circle").font(.headline)
                        Text("Free Fire permite alegerea tipului de țintire în meniul propriu de control. Acest panel nu schimbă automat jocul.").font(.footnote).foregroundStyle(.secondary)
                        Link(destination: URL(string: "https://ffsuporte.garena.com/support/solutions/articles/154000130750-qual-a-diferenca-dos-tipos-de-mira-")!) {
                            Label("Deschide ghidul Garena", systemImage: "arrow.up.right.square").font(.subheadline.bold()).foregroundStyle(violet)
                        }
                    }.padding(18).frame(maxWidth: .infinity, alignment: .leading).background(panel, in: RoundedRectangle(cornerRadius: 20))
                }.padding(20).frame(maxWidth: 620)
            }.frame(maxWidth: .infinity).background(Color(red: 0.045, green: 0.025, blue: 0.075).ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
            .task { load() }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.data], allowsMultipleSelection: true) { result in
                do {
                    var count = 0
                    for url in try result.get() {
                        let scoped = url.startAccessingSecurityScopedResource()
                        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
                        guard ["xit", "lua", "json", "txt"].contains(url.pathExtension.lowercased()), (try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0) <= 2_000_000 else { continue }
                        let data = try Data(contentsOf: url)
                        files.append(ConfigFile(name: url.lastPathComponent, data: data, description: "Import local")); count += 1
                    }
                    try save(); status = "\(count) fișiere importate. Formate: XIT, LUA, JSON, TXT; maximum 2 MB."
                } catch { status = "Import nereușit: \(error.localizedDescription)" }
            }
            .sheet(item: $preview) { file in
                NavigationStack {
                    ScrollView { Text(file.text).font(.system(.body, design: .monospaced)).textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading).padding() }
                        .navigationTitle(file.name).navigationBarTitleDisplayMode(.inline)
                        .toolbar {
                            ToolbarItem(placement: .cancellationAction) { Button("Închide") { preview = nil } }
                            ToolbarItem(placement: .primaryAction) { Button { UIPasteboard.general.string = file.text } label: { Image(systemName: "doc.on.doc") }.accessibilityLabel("Copiază codul") }
                        }
                }
            }
        }
    }
    private func action(_ title: String, _ icon: String, perform: @escaping () -> Void) -> some View {
        Button(action: perform) {
            Label(title, systemImage: icon).font(.headline).foregroundStyle(.white).frame(maxWidth: .infinity).padding(17).background(gradient, in: RoundedRectangle(cornerRadius: 17))
        }.buttonStyle(.plain)
    }
    private var settingsText: String {
        """
        hyravpn — configurare manuală Free Fire
        Scară: 0–\(sensiMax)
        General: \(Int(sensiGeneral))
        Red Dot: \(Int(sensiRedDot))
        2x Scope: \(Int(sensi2x))
        4x Scope: \(Int(sensi4x))
        Sniper Scope: \(Int(sensiSniper))
        Free Look: \(Int(sensiFreeLook))
        Precizie: \(aimPrecision)
        Introdu manual valorile în meniul jocului.
        """
    }
    private var sensitivityPanel: some View {
        VStack(alignment: .leading, spacing: 16) {
            Label("Sensibilitate și precizie", systemImage: "scope").font(.title3.bold())
            Text("Setări salvate automat în hyravpn. Aplică manual valorile în Free Fire.")
                .font(.footnote).foregroundStyle(.secondary)
            Picker("Scara din joc", selection: $sensiMax) {
                Text("0–100").tag(100)
                Text("0–200").tag(200)
            }.pickerStyle(.segmented)
                .onChange(of: sensiMax) { maximum in
                    let m = Double(maximum)
                    sensiGeneral = min(sensiGeneral, m)
                    sensiRedDot = min(sensiRedDot, m)
                    sensi2x = min(sensi2x, m)
                    sensi4x = min(sensi4x, m)
                    sensiSniper = min(sensiSniper, m)
                    sensiFreeLook = min(sensiFreeLook, m)
                }
            sensitivityRow("General", value: $sensiGeneral)
            sensitivityRow("Red Dot", value: $sensiRedDot)
            sensitivityRow("2x Scope", value: $sensi2x)
            sensitivityRow("4x Scope", value: $sensi4x)
            sensitivityRow("Sniper Scope", value: $sensiSniper)
            sensitivityRow("Free Look", value: $sensiFreeLook)
            Picker("Precizia țintirii", selection: $aimPrecision) {
                Text("Implicită").tag("Implicită")
                Text("Precise on Scope").tag("Precise on Scope")
                Text("Full Control").tag("Full Control")
            }.tint(violet)
            action("Copiază setările", "doc.on.doc") {
                UIPasteboard.general.string = settingsText
                status = "Setările au fost copiate. Introdu valorile manual în joc."
            }
            ShareLink(item: settingsText) {
                Label("Distribuie configurația", systemImage: "square.and.arrow.up")
                    .font(.subheadline.bold()).frame(maxWidth: .infinity)
            }.tint(violet)
        }.padding(18).background(panel, in: RoundedRectangle(cornerRadius: 20))
    }
    private func sensitivityRow(_ name: String, value: Binding<Double>) -> some View {
        VStack(spacing: 3) {
            HStack {
                Text(name).font(.subheadline.weight(.medium))
                Spacer()
                Text(String(Int(value.wrappedValue))).font(.subheadline.monospacedDigit().bold()).foregroundStyle(violet)
            }
            Slider(value: value, in: 0...Double(sensiMax), step: 1).tint(violet)
                .accessibilityLabel(name)
        }
    }
    private func runLua() {
        let scripts = files.filter { selected.contains($0.id) && ["lua", "xit"].contains(($0.name as NSString).pathExtension.lowercased()) }
        guard !scripts.isEmpty else { luaOutput = "Selectează un fișier Lua sau XIT cu sursă Lua."; return }
        runningLua = true
        luaOutput = "Executare locală…"
        DispatchQueue.global(qos: .userInitiated).async {
            let results = scripts.map { file -> String in
                var output = [CChar](repeating: 0, count: 4096)
                let code = file.data.withUnsafeBytes { bytes in
                    output.withUnsafeMutableBufferPointer { buffer in
                        hyra_lua_run(bytes.baseAddress, bytes.count, buffer.baseAddress, buffer.count)
                    }
                }
                return "\(file.name): \(code == 0 ? "OK" : "EROARE")\n\(String(cString: output))"
            }.joined(separator: "\n\n")
            DispatchQueue.main.async {
                luaOutput = results
                runningLua = false
            }
        }
    }
    private func load() {
        let builtins: [(String, String)] = [
            ("hs_head", "Calcul geometric local"),
            ("recoil_zero", "Calcul numeric local"),
            ("sensi_aim", "Calculator de sensibilitate"),
            ("sensi_calibre", "Conversie intre scari"),
            ("aim_precision", "Calculul erorii absolute"),
            ("aim_assist", "Statistica valorilor locale")
        ]
        let included = builtins.compactMap { item -> ConfigFile? in
            guard let url = Bundle.main.url(forResource: item.0, withExtension: "xit", subdirectory: "Modules"),
                  let data = try? Data(contentsOf: url) else { return nil }
            return ConfigFile(name: item.0 + ".xit", data: data, description: item.1, bundled: true)
        }
        let saved = (try? Data(contentsOf: storage)).flatMap { try? JSONDecoder().decode([ConfigFile].self, from: $0) } ?? []
        files = included + saved.filter { !$0.bundled }
        selected = []
        status = "\(included.count)/6 scripturi integrate • executie exclusiv locala"
    }
    private func save() throws {
        try FileManager.default.createDirectory(at: storage.deletingLastPathComponent(), withIntermediateDirectories: true)
        try JSONEncoder().encode(files.filter { !$0.bundled }).write(to: storage, options: .atomic)
    }
}
