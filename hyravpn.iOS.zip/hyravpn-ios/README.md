# hyravpn — Lua

Actualizare a proiectului iOS existent. Importa fisiere .lua sau .xit care contin sursa Lua. Selecteaza si apasa Executa scripturile selectate. Rezultatul sau eroarea este afisata in aplicatie. Sunt incluse sase module .xit cu operatii matematice locale. Numele modulelor nu implica acces la joc. Nu sunt cheat-uri si nu controleaza tinta/reculul. Fara biblioteci standard Lua expuse, fara acces la fisiere/retea din scripturi, limita 8 MB si aproximativ 1 milion instructiuni per executie. Limita sursei 256 KB. Doar cod text Lua, nu bytecode. 

Build: scriptul prepare-lua.sh descarca Lua 5.4.9 de pe lua.org, verifica SHA256 si compileaza biblioteca statica in faza Xcode Prepare Lua. Repo-ul anterior poate folosi acelasi workflow (unzip hyravpn_iOS.zip apoi xcodebuild). Pentru actualizare, redenumeste arhiva in hyravpn_iOS.zip si inlocuieste-o in GitHub. IPA-ul ramane nesemnat.

Verificarea pe iPhone/Xcode si descarcarea bibliotecii nu au fost efectuate in mediul Linux.
