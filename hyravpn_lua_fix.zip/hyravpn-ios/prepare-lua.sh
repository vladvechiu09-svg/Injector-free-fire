#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
VERSION=5.4.9
HASH=2335b6c582a52654f94612bf10d2f4672805d05329aa6568b1d8cd9e5c6fb8e6
PLATFORM="${PLATFORM_NAME:-iphoneos}"
OUT="$PWD/LuaBuild/$PLATFORM"
mkdir -p "$OUT/objects"
ARCHIVE="$PWD/LuaBuild/lua-$VERSION.tar.gz"
if [ ! -f "$ARCHIVE" ]; then
  curl --fail --location --retry 3 "https://www.lua.org/ftp/lua-$VERSION.tar.gz" -o "$ARCHIVE.tmp"
  mv "$ARCHIVE.tmp" "$ARCHIVE"
fi
printf '%s  %s\n' "$HASH" "$ARCHIVE" | shasum -a 256 -c -
tar -xzf "$ARCHIVE" -C "$PWD/LuaBuild"
LUA="$PWD/LuaBuild/lua-$VERSION/src"
SDK=$(xcrun --sdk "$PLATFORM" --show-sdk-path)
ARCHS_TO_BUILD="${ARCHS:-arm64}"
rm -f "$OUT"/objects/*.o "$OUT"/libluaengine.a
libs=()
for arch in $ARCHS_TO_BUILD; do
  mkdir -p "$OUT/objects/$arch"
  rm -f "$OUT/objects/$arch"/*.o
  if [ "$PLATFORM" = "iphonesimulator" ]; then MINFLAG=-mios-simulator-version-min=16.0; else MINFLAG=-miphoneos-version-min=16.0; fi
  for source in "$LUA"/*.c "$PWD/hyravpn/LuaBridge.c"; do
    # The local sandboxed runner does not expose Lua standard libraries.
    # In particular loslib.c calls system(), unavailable on iOS.
    case "$(basename "$source")" in
      lua.c|luac.c|onelua.c|linit.c|lbaselib.c|lcorolib.c|ldblib.c|liolib.c|lmathlib.c|loadlib.c|loslib.c|lstrlib.c|ltablib.c|lutf8lib.c) continue;;
    esac
    xcrun --sdk "$PLATFORM" clang -arch "$arch" -isysroot "$SDK" "$MINFLAG" -O2 -I "$LUA" -c "$source" -o "$OUT/objects/$arch/$(basename "$source" .c).o"
  done
  xcrun --sdk "$PLATFORM" ar rcs "$OUT/liblua-$arch.a" "$OUT/objects/$arch"/*.o
  libs+=("$OUT/liblua-$arch.a")
done
if [ "${#libs[@]}" -eq 1 ]; then cp "${libs[0]}" "$OUT/libluaengine.a"; else xcrun lipo -create "${libs[@]}" -output "$OUT/libluaengine.a"; fi
