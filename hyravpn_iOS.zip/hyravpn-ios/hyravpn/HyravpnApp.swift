import SwiftUI
import UniformTypeIdentifiers
import UIKit

@main
struct HyravpnApp: App {
    var body: some Scene { WindowGroup { ContentView().preferredColorScheme(.dark) } }
}

struct ConfigFile: Identifiable, Codable {
    var id = UUID()
    var name: String
    var data: Data
    var description: String
    var bundled = false
    var text: String { String(data: data, encoding: .utf8) ?? "Fișier binar: \(data.count) octeți" }
}

struct ContentView: View {
    @Environment(\.openURL) private var openURL
    @AppStorage("confirmedNames") private var confirmedNames = ""
    @State private var files: [ConfigFile] = []
    @State private var selected = Set<UUID>()
    @State private var importing = false
    @State private var preview: ConfigFile?
    @State private var status = "Fișiere locale • fără acces la datele jocului"
    private let violet = Color(red: 0.67, green: 0.35, blue: 0.98)
    private let panel = Color(red: 0.10, green: 0.065, blue: 0.15)
    private let gradient = LinearGradient(colors: [Color(red: 0.50, green: 0.12, blue: 0.83), Color(red: 0.85, green: 0.15, blue: 0.28), Color(red: 1, green: 0.65, blue: 0.13)], startPoint: .leading, endPoint: .trailing)
    private var storage: URL { FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("hyravpn-files.json") }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    HStack {
                        Image(systemName: "shield.lefthalf.filled").font(.system(size: 28)).foregroundStyle(violet)
                        Text("hyravpn").font(.system(size: 32, weight: .heavy, design: .rounded))
                        Spacer()
                        Text("iOS").font(.caption.bold()).padding(8).background(panel, in: Capsule())
                    }
                    Capsule().fill(gradient).frame(height: 3)
                    VStack(spacing: 10) {
                        Image(systemName: "gamecontroller.fill").font(.system(size: 55)).foregroundStyle(gradient)
                        Text("FREE FIRE").font(.title2.bold()).tracking(3)
                        Text("Lansator de joc").font(.subheadline).foregroundStyle(.secondary)
                    }.frame(maxWidth: .infinity).padding(28).background(panel, in: RoundedRectangle(cornerRadius: 24)).overlay(RoundedRectangle(cornerRadius: 24).stroke(violet.opacity(0.3)))
                    action("Deschide Free Fire", "arrow.up.forward.app") {
                        guard let url = URL(string: "freefire://") else { return }
                        openURL(url) { accepted in if !accepted { status = "iOS nu a găsit o aplicație care acceptă freefire://." } }
                    }
                    HStack {
                        Text("Fișiere .xit").font(.title3.bold())
                        Spacer()
                        Button(selected.count == files.count && !files.isEmpty ? "Deselectează" : "Selectează tot") {
                            selected = selected.count == files.count ? [] : Set(files.map(\.id))
                        }.font(.caption.bold()).foregroundStyle(violet)
                    }
                    ForEach(files) { file in
                        HStack(spacing: 12) {
                            Button { if selected.contains(file.id) { selected.remove(file.id) } else { selected.insert(file.id) } } label: {
                                Image(systemName: selected.contains(file.id) ? "checkmark.square.fill" : "square").font(.title2).foregroundStyle(violet)
                            }.buttonStyle(.plain).accessibilityLabel("Selectează \(file.name)")
                            Image(systemName: "doc.text").foregroundStyle(violet)
                            VStack(alignment: .leading, spacing: 5) {
                                Text(file.name).font(.subheadline.bold()).lineLimit(2)
                                Text(file.description).font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Button { preview = file } label: { Image(systemName: "chevron.right").padding(8).foregroundStyle(violet) }.buttonStyle(.plain).accessibilityLabel("Vezi codul \(file.name)")
                        }.padding(16).background(panel, in: RoundedRectangle(cornerRadius: 16))
                    }
                    Button { importing = true } label: {
                        Label("Importă fișiere", systemImage: "folder.badge.plus").font(.headline).frame(maxWidth: .infinity).padding(16).overlay(RoundedRectangle(cornerRadius: 16).stroke(violet.opacity(0.6)))
                    }.buttonStyle(.plain)
                    action("Confirmă selecția (\(selected.count))", "checkmark") {
                        let names = files.filter { selected.contains($0.id) }.map(\.name)
                        confirmedNames = names.joined(separator: "\n")
                        status = "\(names.count) fișiere selectate și salvate local."
                    }.disabled(selected.isEmpty).opacity(selected.isEmpty ? 0.5 : 1)
                    Text(status).font(.footnote).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading)
                    if !confirmedNames.isEmpty {
                        Text("Ultima selecție: " + confirmedNames.replacingOccurrences(of: "\n", with: ", ")).font(.caption).foregroundStyle(.secondary)
                    }
                }.padding(20).frame(maxWidth: 620)
            }.frame(maxWidth: .infinity).background(Color(red: 0.045, green: 0.025, blue: 0.075).ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
            .task { load() }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.data], allowsMultipleSelection: true) { result in
                do {
                    var count = 0
                    for url in try result.get() {
                        let scoped = url.startAccessingSecurityScopedResource()
                        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
                        guard ["xit", "json", "txt"].contains(url.pathExtension.lowercased()), (try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0) <= 2_000_000 else { continue }
                        let data = try Data(contentsOf: url)
                        files.append(ConfigFile(name: url.lastPathComponent, data: data, description: "Import local")); count += 1
                    }
                    try save(); status = "\(count) fișiere importate. Formate: XIT, JSON, TXT; maximum 2 MB."
                } catch { status = "Import nereușit: \(error.localizedDescription)" }
            }
            .sheet(item: $preview) { file in
                NavigationStack {
                    ScrollView { Text(file.text).font(.system(.body, design: .monospaced)).textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading).padding() }
                        .navigationTitle(file.name).navigationBarTitleDisplayMode(.inline)
                        .toolbar {
                            ToolbarItem(placement: .cancellationAction) { Button("Închide") { preview = nil } }
                            ToolbarItem(placement: .primaryAction) { Button { UIPasteboard.general.string = file.text } label: { Image(systemName: "doc.on.doc") }.accessibilityLabel("Copiază codul") }
                        }
                }
            }
        }
    }
    private func action(_ title: String, _ icon: String, perform: @escaping () -> Void) -> some View {
        Button(action: perform) {
            Label(title, systemImage: icon).font(.headline).foregroundStyle(.white).frame(maxWidth: .infinity).padding(17).background(gradient, in: RoundedRectangle(cornerRadius: 17))
        }.buttonStyle(.plain)
    }
    private func load() {
        if let data = try? Data(contentsOf: storage), let saved = try? JSONDecoder().decode([ConfigFile].self, from: data) { files = saved; return }
        let names = ["sensi_calibre", "recoil_adjust", "hs_central", "hs_head"]
        files = names.compactMap { name in
            guard let url = Bundle.main.url(forResource: name, withExtension: "xit"), let data = try? Data(contentsOf: url) else { return nil }
            return ConfigFile(name: name + ".xit", data: data, description: "Configurație veche • doar vizualizare", bundled: true)
        }
        try? save()
    }
    private func save() throws {
        try FileManager.default.createDirectory(at: storage.deletingLastPathComponent(), withIntermediateDirectories: true)
        try JSONEncoder().encode(files).write(to: storage, options: .atomic)
    }
}
