# hyravpn — iOS
Proiect nativ SwiftUI, iOS 16+. Interfață violet închis, gradient roșu-portocaliu. Importă și salvează local fișiere XIT/JSON/TXT, permite selectarea și citirea codului. Lansează URL-ul freefire:// dacă jocul îl acceptă.

Cele patru fișiere XIT sunt păstrate din proiectul anterior; conțin date JSON vechi pentru trainer și sunt doar vizualizabile. Nu există trainer, injector, VPN, modificare a jocului sau mesaje de injectare. Confirmarea salvează doar selecția locală. Nu există certificat root sau permisiuni speciale.

## Mac
Deschide hyravpn.xcodeproj în Xcode, selectează echipa ta de semnare în Signing & Capabilities, schimbă Bundle Identifier dacă este necesar, selectează iPhone și apasă Run.

## Windows
Creează un repository GitHub și încarcă toate fișierele proiectului (inclusiv .github/workflows/build.yml). În Actions selectează Build hyravpn iOS, Run workflow. Dacă buildul reușește, descarcă artifactul hyravpn-unsigned. IPA-ul este NESEMNAT și necesită semnare validă Apple înainte de instalare. Nu include certificate sau conturi. Workflow-ul poate necesita acces la Actions și minute disponibile.

Verificare locală: sintaxă Swift parsată, proiect și resurse inspectate. Compilarea iOS, instalarea și deschiderea jocului nu au fost testate, deoarece mediul de creare este Linux fără Xcode.
